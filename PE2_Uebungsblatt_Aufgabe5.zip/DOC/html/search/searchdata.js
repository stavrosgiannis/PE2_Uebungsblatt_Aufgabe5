var indexSectionsWithContent =
{
  0: "_dehilmprst~",
  1: "eh",
  2: "ehp",
  3: "dehilmprst~",
  4: "_",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "Alle",
  1: "Klassen",
  2: "Dateien",
  3: "Funktionen",
  4: "Variablen",
  5: "Makrodefinitionen"
};

